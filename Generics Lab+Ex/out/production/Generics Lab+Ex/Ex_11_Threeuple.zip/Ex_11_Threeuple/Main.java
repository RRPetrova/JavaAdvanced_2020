package Ex_11_Threeuple;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] input1 = scanner.nextLine().split("\\s+");
        Threeuple threeuple = new Threeuple(input1[0] + " " + input1[1],
                input1[2], input1[3]);
        System.out.println(threeuple);

        input1 = scanner.nextLine().split("\\s+");
        boolean isDrunk = false;
        if (input1[2].equals("drunk")) {
            isDrunk = true;
        }
        threeuple = new Threeuple(input1[0], Integer.parseInt(input1[1]),
                isDrunk);
        System.out.println(threeuple);

        input1 = scanner.nextLine().split("\\s+");
        threeuple = new Threeuple(input1[0], Double.parseDouble(input1[1]),
                input1[2]);
        System.out.println(threeuple);

    }
}
